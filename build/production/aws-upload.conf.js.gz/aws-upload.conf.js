module.exports = {
    credentials:"../../aws-credentials.json",
    bucketName:"jampp-blog.com",
    patterns:[
        "**"
    ]
}
